"""Run one deterministic policy checkpoint over repeated environment seeds.

This runner is deliberately separate from the frozen Octo policy-seed batches.
It keeps the checkpoint fixed and treats environment seeds as the finite
repetition source for the cross-family confirmation. The client/server wire
protocol is the existing official ManiSkill3 bridge.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import sys
import time


ENV_IDS = [
    "PutCarrotOnPlateInScene-v1",
    "PutSpoonOnTableClothInScene-v1",
    "StackGreenCubeOnYellowCubeBakedTexInScene-v1",
    "PutEggplantInBasketScene-v1",
]
EXPECTED_COUNTS = {
    "PutCarrotOnPlateInScene-v1": 24,
    "PutSpoonOnTableClothInScene-v1": 24,
    "StackGreenCubeOnYellowCubeBakedTexInScene-v1": 24,
    "PutEggplantInBasketScene-v1": 64,
}


def reported_policy_seed(policy_name: str, requested_policy_seed: int) -> int | None:
    """Return the seed semantics reported by the policy, not the wire request."""
    if policy_name == "rt-1-x":
        return None
    return requested_policy_seed


def policy_seed_rule(policy_name: str, requested_policy_seed: int) -> str:
    if policy_name == "rt-1-x":
        return (
            f"client request seed {requested_policy_seed} is retained for wire compatibility; "
            "RT-1-X ignores it and reports no per-episode policy seed"
        )
    return "fixed policy seed"


def expected_batch_metadata(
    *,
    policy_name: str,
    environment_seeds: list[int],
    manifest: Path,
    manifest_hash: str,
    scenario_count: int,
    total_jobs: int,
    requested_policy_seed: int,
) -> dict[str, object]:
    return {
        "policy_name": policy_name,
        "environment_seeds": environment_seeds,
        "scenario_manifest": str(manifest),
        "scenario_manifest_sha256": manifest_hash,
        "scenario_count": scenario_count,
        "total_jobs": total_jobs,
        "policy_seed": reported_policy_seed(policy_name, requested_policy_seed),
    }


def validate_resumed_results(
    results: list[dict[str, object]],
    *,
    jobs: list[tuple[int, str, int]],
    policy_name: str,
    requested_policy_seed: int,
) -> set[tuple[int, str, int]]:
    expected_keys = set(jobs)
    expected_seed = reported_policy_seed(policy_name, requested_policy_seed)
    completed_keys: set[tuple[int, str, int]] = set()
    for row in results:
        key = (int(row["seed"]), str(row["env_id"]), int(row["episode_id"]))
        if key not in expected_keys or key in completed_keys:
            raise ValueError(f"resume output contains duplicate or unexpected row: {key}")
        if row.get("policy_seed") != expected_seed:
            raise ValueError(f"resume row policy seed mismatch: {key}")
        if not isinstance(row.get("final_success"), bool):
            raise ValueError(f"resume row outcome is not Boolean: {key}")
        completed_keys.add(key)
    return completed_keys


def build_episode_command(
    *,
    client: Path,
    env_id: str,
    environment_seed: int,
    episode_id: int,
    requested_policy_seed: int,
    shutdown_server: bool,
) -> list[str]:
    command = [
        sys.executable,
        str(client),
        "--env-id",
        env_id,
        "--seed",
        str(environment_seed),
        "--episode-id",
        str(episode_id),
        "--policy-seed",
        str(requested_policy_seed),
    ]
    if shutdown_server:
        command.append("--shutdown-server")
    return command


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json_atomic(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    for attempt in range(20):
        try:
            temporary.replace(path)
            return
        except PermissionError:
            if attempt == 19:
                raise
            time.sleep(min(0.05 * (2**attempt), 0.5))


def load_manifest(path: Path) -> tuple[list[tuple[str, int]], str]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    scenarios = [
        (str(row["env_id"]), int(row["episode_id"]))
        for row in payload.get("scenarios", [])
    ]
    expected = [
        (env_id, episode_id)
        for env_id in ENV_IDS
        for episode_id in range(EXPECTED_COUNTS[env_id])
    ]
    if scenarios != expected:
        raise ValueError("manifest is not the frozen ordered 136-scenario universe")
    return scenarios, sha256(path)


def task_summary(results: list[dict[str, object]], env_id: str) -> dict[str, object]:
    rows = [row for row in results if str(row["env_id"]) == env_id]
    successes = sum(bool(row["final_success"]) for row in rows)
    return {
        "episodes": len(rows),
        "successes": successes,
        "success_rate": statistics.fmean(
            float(bool(row["final_success"])) for row in rows
        ),
        "unique_environment_seeds": sorted({int(row["seed"]) for row in rows}),
        "unique_action_hashes": len(
            {str(row["environment_action_sha256"]) for row in rows}
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--policy-name", choices=("octo-small", "octo-base", "rt-1-x"), required=True)
    parser.add_argument("--environment-seeds", required=True, help="comma-separated finite repetition seeds")
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--policy-seed", type=int, default=0)
    parser.add_argument("--simpler-root", type=Path, default=Path(r"C:\Users\User\src\SimplerEnv-ms3"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--checkpoint-every", type=int, default=1)
    parser.add_argument("--shutdown-server", action="store_true")
    args = parser.parse_args()
    if args.checkpoint_every < 1:
        raise ValueError("--checkpoint-every must be at least 1")
    environment_seeds = [int(value) for value in args.environment_seeds.split(",")]
    if len(environment_seeds) != len(set(environment_seeds)) or not environment_seeds:
        raise ValueError("environment seeds must be non-empty and unique")
    scenarios, manifest_hash = load_manifest(args.manifest)
    jobs = [
        (environment_seed, env_id, episode_id)
        for environment_seed in environment_seeds
        for env_id, episode_id in scenarios
    ]
    client = Path(__file__).with_name("run-octo-small-policy-episode.py")
    process_environment = dict(__import__("os").environ)
    process_environment["PYTHONPATH"] = str(args.simpler_root)
    results: list[dict[str, object]] = []
    requested_policy_seed = args.policy_seed
    envelope_policy_seed = reported_policy_seed(args.policy_name, requested_policy_seed)
    if args.resume and args.output.exists():
        previous = json.loads(args.output.read_text(encoding="utf-8"))
        expected_metadata = expected_batch_metadata(
            policy_name=args.policy_name,
            environment_seeds=environment_seeds,
            manifest=args.manifest,
            manifest_hash=manifest_hash,
            scenario_count=len(scenarios),
            total_jobs=len(jobs),
            requested_policy_seed=requested_policy_seed,
        )
        for key, expected in expected_metadata.items():
            if previous.get(key) != expected:
                raise ValueError(
                    f"resume metadata mismatch for {key}: {previous.get(key)!r} != {expected!r}"
                )
        previous_results = previous.get("results")
        if not isinstance(previous_results, list):
            raise ValueError("resume output results must be a list")
        results = list(previous_results)
    completed_keys = validate_resumed_results(
        results,
        jobs=jobs,
        policy_name=args.policy_name,
        requested_policy_seed=requested_policy_seed,
    )

    def checkpoint(status: str = "in-progress") -> None:
        payload: dict[str, object] = {
            "schema_version": 1,
            "probe_type": "cross-family fixed-checkpoint environment-seed batch",
            "policy_name": args.policy_name,
            "policy_seed": envelope_policy_seed,
            "policy_seed_rule": policy_seed_rule(args.policy_name, requested_policy_seed),
            "environment_seeds": environment_seeds,
            "scenario_manifest": str(args.manifest),
            "scenario_manifest_sha256": manifest_hash,
            "scenario_count": len(scenarios),
            "total_jobs": len(jobs),
            "completed_jobs": len(results),
            "results": results,
            "status": status,
        }
        write_json_atomic(args.output, payload)

    for job_index, (environment_seed, env_id, episode_id) in enumerate(jobs):
        job_key = (environment_seed, env_id, episode_id)
        if job_key in completed_keys:
            continue
        command = build_episode_command(
            client=client,
            env_id=env_id,
            environment_seed=environment_seed,
            episode_id=episode_id,
            requested_policy_seed=requested_policy_seed,
            shutdown_server=args.shutdown_server and job_index == len(jobs) - 1,
        )
        completed = subprocess.run(
            command,
            check=False,
            capture_output=True,
            text=True,
            env=process_environment,
        )
        if completed.returncode != 0:
            raise RuntimeError(
                f"episode failed for seed={environment_seed} {env_id}/{episode_id}:\n"
                f"STDOUT:\n{completed.stdout}\nSTDERR:\n{completed.stderr}"
            )
        result = json.loads(completed.stdout)
        if int(result["seed"]) != environment_seed or int(result["episode_id"]) != episode_id:
            raise ValueError("client returned a mismatched environment/scenario key")
        if result.get("policy_seed") != envelope_policy_seed:
            raise ValueError(
                f"{args.policy_name} result returned a mismatched reported policy seed"
            )
        results.append(result)
        completed_keys.add(job_key)
        if len(results) % args.checkpoint_every == 0 or len(results) == len(jobs):
            checkpoint()
        print(
            f"completed {len(results)}/{len(jobs)} {args.policy_name} "
            f"environment_seed={environment_seed} {env_id} episode_id={episode_id} "
            f"success={result['final_success']}",
            file=sys.stderr,
            flush=True,
        )

    if len(results) != len(jobs):
        raise AssertionError("batch did not complete all frozen jobs")
    checkpoints = sorted({str(row["checkpoint"]) for row in results})
    report = {
        "schema_version": 1,
        "probe_type": "cross-family fixed-checkpoint environment-seed batch",
        "policy_name": args.policy_name,
        "checkpoints": checkpoints,
        "policy_seed": envelope_policy_seed,
        "policy_seed_rule": policy_seed_rule(args.policy_name, requested_policy_seed),
        "environment_seeds": environment_seeds,
        "scenario_manifest": str(args.manifest),
        "scenario_manifest_sha256": manifest_hash,
        "scenario_count": len(scenarios),
        "total_jobs": len(jobs),
        "completed_jobs": len(results),
        "episodes": len(results),
        "task_summaries": {
            env_id: task_summary(results, env_id) for env_id in ENV_IDS
        },
        "results": results,
        "status": "pass",
    }
    write_json_atomic(args.output, report)
    print(json.dumps({
        "status": report["status"],
        "policy_name": args.policy_name,
        "episodes": report["episodes"],
        "output": str(args.output),
        "output_sha256": sha256(args.output),
    }, indent=2))


if __name__ == "__main__":
    main()
