"""Replay one frozen T1 environment-seed tensor without post-result gating."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import random
import statistics
import sys
import time
from typing import Any

from preference_decomposed_eig import BetaPosterior, ranking_pd_eig
import ranksplit_v2
from ranksplit_established_ranking_allocators import (
    SaadTaskwiseState,
    SRankSingletonState,
    stable_seed,
)
from ranksplit_ranking_metrics import evaluate
import screen_preference_decomposed_eig as BASE

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import ranksplit_environment_seed_transfer_contract as CONTRACT  # noqa: E402


ROW_METRICS = (
    "task_weak_order_exact_rate",
    "task_pair_relation_accuracy",
    "task_top_set_jaccard",
    "mean_task_gap_mae",
    "mean_decision_regret",
    "runtime_seconds",
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def seed_view(tensor: dict[str, Any], environment_seed: int) -> dict[str, Any]:
    CONTRACT.require(environment_seed in CONTRACT.ENVIRONMENT_SEEDS, "T1 environment seed is outside the freeze")
    offset = CONTRACT.ENVIRONMENT_SEEDS.index(environment_seed)
    records = []
    for record in tensor["scenario_records"]:
        policies = {}
        for role in CONTRACT.POLICY_ORDER:
            values = record["policies"][role]["environment_seed_outcomes"]
            policies[role] = {"outcome": int(values[offset])}
        records.append(
            {
                "env_id": str(record["env_id"]),
                "episode_id": int(record["episode_id"]),
                "policies": policies,
            }
        )
    return {
        "policy_order": list(CONTRACT.POLICY_ORDER),
        "scenario_records": records,
        "status": "pass",
    }


def prepare_tensor(tensor: dict[str, Any]):
    policies = tuple(tensor["policy_order"])
    scenarios = list(tensor["scenario_records"])
    task_lookup = {name: index for index, name in enumerate(CONTRACT.ENV_IDS)}
    task_groups = {index: [] for index in range(len(CONTRACT.ENV_IDS))}
    outcomes: dict[tuple[int, int], int] = {}
    for scenario_index, scenario in enumerate(scenarios):
        task = task_lookup[str(scenario["env_id"])]
        task_groups[task].append(scenario_index)
        for policy, name in enumerate(policies):
            outcomes[(scenario_index, policy)] = int(scenario["policies"][name]["outcome"])
    truth_rates = tuple(
        tuple(
            statistics.fmean(outcomes[(scenario, policy)] for scenario in task_groups[task])
            for policy in range(len(policies))
        )
        for task in task_groups
    )
    return policies, list(CONTRACT.ENV_IDS), task_groups, outcomes, truth_rates


def scenario_orders_for_repetition(
    *, master_seed: int, environment_seed: int, repetition: int, task_groups: dict[int, list[int]], policy_count: int
) -> dict[tuple[int, int], list[int]]:
    orders: dict[tuple[int, int], list[int]] = {}
    for task, indices in task_groups.items():
        for policy in range(policy_count):
            rng = random.Random(
                stable_seed(master_seed, "scenario-order", environment_seed, repetition, task, policy)
            )
            orders[(task, policy)] = rng.sample(indices, len(indices))
    return orders


def choose_outer_task(
    *, positions: dict[tuple[int, int], int], scenario_orders: dict[tuple[int, int], list[int]],
    task_groups: dict[int, list[int]], environment_seed: int, repetition: int, global_step: int, master_seed: int,
) -> int:
    available = [
        task for task in task_groups
        if any(positions[(task, policy)] < len(scenario_orders[(task, policy)]) for policy in range(3))
    ]
    CONTRACT.require(bool(available), "T1 outer scheduler exhausted before endpoint")
    counts = {task: sum(positions[(task, policy)] for policy in range(3)) for task in available}
    minimum = min(counts.values())
    tied = [task for task in available if counts[task] == minimum]
    return max(
        tied,
        key=lambda task: stable_seed(
            master_seed, "outer-task-tie", environment_seed, repetition, global_step, task
        ),
    )


def choose_scored_policy(
    *, family: str, preference_lambda: float, states: tuple[BetaPosterior, ...],
    positions: dict[tuple[int, int], int], scenario_orders: dict[tuple[int, int], list[int]],
    task: int, environment_seed: int, repetition: int, global_step: int, master_seed: int,
) -> int:
    candidates: list[tuple[float, int, int]] = []
    for policy, _state in enumerate(states):
        if positions[(task, policy)] >= len(scenario_orders[(task, policy)]):
            continue
        if family == "matched-eig":
            score = BASE.acquisition_score(
                "B0", states=states, policy=policy, preference_lambda=0.0,
                progress=0.0, switching=0, ratio_switch_penalty=0.0, lagrangian_switch_nats=0.0,
            )
        elif family == "ranksplit":
            score = ranking_pd_eig(
                states,
                observed_policy=policy,
                preference_lambda=preference_lambda,
            ).score
        elif family == "clarity-continuation":
            score = ranksplit_v2.clarity_continuation_score(
                states, observed_policy=policy, preference_lambda=preference_lambda
            )
        else:
            raise ValueError(f"unknown T1 scored family: {family}")
        tie = stable_seed(
            master_seed, "inner-policy-tie", environment_seed, repetition, global_step, task, policy
        )
        candidates.append((float(score), tie, policy))
    CONTRACT.require(bool(candidates), "T1 scored selector exhausted before endpoint")
    return max(candidates)[2]


def run_program(
    *, family: str, preference_lambda: float, scenario_orders: dict[tuple[int, int], list[int]],
    task_groups: dict[int, list[int]], outcomes: dict[tuple[int, int], int], truth_rates: tuple[tuple[float, ...], ...],
    budgets: list[int], environment_seed: int, repetition: int, protocol: dict[str, Any],
):
    policy_count = len(truth_rates[0])
    observed = {(task, policy): [] for task in task_groups for policy in range(policy_count)}
    positions = {key: 0 for key in observed}
    alpha = [[1 for _ in task_groups] for _ in range(policy_count)]
    beta = [[1 for _ in task_groups] for _ in range(policy_count)]
    for task in task_groups:
        for policy in range(policy_count):
            scenario = scenario_orders[(task, policy)][0]
            outcome = outcomes[(scenario, policy)]
            observed[(task, policy)].append(outcome)
            positions[(task, policy)] = 1
            alpha[policy][task] += outcome
            beta[policy][task] += 1 - outcome

    capacities = {task: tuple(len(scenario_orders[(task, policy)]) for policy in range(policy_count)) for task in task_groups}
    master_seed = int(protocol["replay"]["simulation_seed"])
    allocator_states: dict[int, Any] = {}
    if family == "saad-taskwise-d1":
        config = protocol["allocators"]["saad_taskwise_d1"]
        for task in task_groups:
            allocator_states[task] = SaadTaskwiseState(
                task=task, repetition=repetition, master_seed=master_seed,
                capacities=capacities[task], counts=[1] * policy_count,
                successes=[observed[(task, policy)][0] for policy in range(policy_count)],
                task_count=CONTRACT.TASK_COUNT, delta=float(config["delta"]),
            )
    elif family == "srank-singleton":
        config = protocol["allocators"]["srank_singleton"]
        for task in task_groups:
            allocator_states[task] = SRankSingletonState(
                task=task, repetition=repetition, master_seed=master_seed,
                capacities=capacities[task], counts=[1] * policy_count,
                successes=[observed[(task, policy)][0] for policy in range(policy_count)],
                horizon=int(config["horizon_per_task"]), rounds=int(config["rounds"]),
            )

    acquired = sum(map(len, observed.values()))
    maximum_budget = max(budgets)
    rows: dict[str, dict[str, float]] = {}
    trace: list[tuple[int, int]] = []
    runtime_seconds = 0.0
    while True:
        if acquired in budgets:
            row = evaluate(observed, truth_rates)
            row.update(runtime_seconds=runtime_seconds)
            rows[str(acquired)] = row
        if acquired >= maximum_budget:
            break
        task = choose_outer_task(
            positions=positions, scenario_orders=scenario_orders, task_groups=task_groups,
            environment_seed=environment_seed, repetition=repetition, global_step=acquired, master_seed=master_seed,
        )
        states = tuple(BetaPosterior(alpha[policy][task], beta[policy][task]) for policy in range(policy_count))
        started = time.perf_counter()
        if family in ("saad-taskwise-d1", "srank-singleton"):
            policy = allocator_states[task].choose_policy(global_step=acquired)
        else:
            policy = choose_scored_policy(
                family=family, preference_lambda=preference_lambda, states=states,
                positions=positions, scenario_orders=scenario_orders, task=task,
                environment_seed=environment_seed, repetition=repetition, global_step=acquired, master_seed=master_seed,
            )
        runtime_seconds += time.perf_counter() - started
        position = positions[(task, policy)]
        CONTRACT.require(position < len(scenario_orders[(task, policy)]), "T1 selector returned an exhausted cell")
        scenario = scenario_orders[(task, policy)][position]
        positions[(task, policy)] += 1
        outcome = outcomes[(scenario, policy)]
        observed[(task, policy)].append(outcome)
        alpha[policy][task] += outcome
        beta[policy][task] += 1 - outcome
        if family in ("saad-taskwise-d1", "srank-singleton"):
            allocator_states[task].update(policy, outcome)
        acquired += 1
        trace.append((task, policy))

    CONTRACT.require(acquired == CONTRACT.FULL_ENDPOINT, "T1 replay did not reach complete endpoint")
    return rows, hashlib.sha256(json.dumps(trace, separators=(",", ":")).encode("utf-8")).hexdigest()


def replay_tensor(
    *, tensor: dict[str, Any], protocol: dict[str, Any], protocol_path: Path, environment_seed: int
) -> dict[str, Any]:
    view = seed_view(tensor, environment_seed)
    policies, task_names, task_groups, outcomes, truth_rates = prepare_tensor(view)
    CONTRACT.require(tuple(policies) == CONTRACT.POLICY_ORDER, "T1 replay policy order changed")
    budgets = list(map(int, protocol["sampling_design"]["budgets"]))
    rows = {role: {str(budget): [] for budget in budgets} for role in CONTRACT.PROGRAM_ORDER}
    traces = {role: [] for role in CONTRACT.PROGRAM_ORDER}
    repetitions = int(protocol["replay"]["tensor_repetitions"])
    for repetition in range(repetitions):
        orders = scenario_orders_for_repetition(
            master_seed=int(protocol["replay"]["simulation_seed"]), environment_seed=environment_seed,
            repetition=repetition, task_groups=task_groups, policy_count=len(policies),
        )
        for program in protocol["programs"]:
            role = str(program["role"])
            program_rows, trace_hash = run_program(
                family=str(program["family"]), preference_lambda=float(program["preference_lambda"]),
                scenario_orders=orders, task_groups=task_groups, outcomes=outcomes, truth_rates=truth_rates,
                budgets=budgets, environment_seed=environment_seed, repetition=repetition, protocol=protocol,
            )
            for budget in budgets:
                rows[role][str(budget)].append(program_rows[str(budget)])
            traces[role].append(trace_hash)
    return {
        "schema_version": 1,
        "status": "complete-tensor-replay-no-evaluation",
        "evidence_class": protocol["evidence_class"],
        "environment_seed": environment_seed,
        "repetitions": repetitions,
        "repetition_indices": list(range(repetitions)),
        "budgets": budgets,
        "primary_budgets": list(map(int, protocol["sampling_design"]["primary_budgets"])),
        "policy_order": list(policies),
        "task_names": task_names,
        "programs": [
            {"role": str(row["role"]), "family": str(row["family"]), "preference_lambda": float(row["preference_lambda"])}
            for row in protocol["programs"]
        ],
        "rows": rows,
        "action_trace_sha256": traces,
        "source": {
            "protocol_sha256": sha256(protocol_path),
            "tensor_sha256": "",
            "replay_sha256": sha256(Path(__file__).resolve()),
            "allocator_sha256": sha256(ROOT / "scripts" / "ranksplit_established_ranking_allocators.py"),
            "ranksplit_v2_sha256": sha256(ROOT / "scripts" / "ranksplit_v2.py"),
            "metrics_sha256": sha256(ROOT / "scripts" / "ranksplit_ranking_metrics.py"),
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--tensor", type=Path, required=True)
    parser.add_argument("--environment-seed", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    protocol_path = args.protocol.resolve()
    tensor_path = args.tensor.resolve()
    protocol = CONTRACT.load_protocol(protocol_path)
    tensor = json.loads(tensor_path.read_text(encoding="utf-8"))
    CONTRACT.validate_tensor_payload(tensor, protocol=protocol, protocol_path=protocol_path)
    CONTRACT.require(args.environment_seed in CONTRACT.ENVIRONMENT_SEEDS, "T1 environment seed is outside the freeze")
    report = replay_tensor(
        tensor=tensor,
        protocol=protocol,
        protocol_path=protocol_path,
        environment_seed=args.environment_seed,
    )
    report["source"]["tensor_sha256"] = sha256(tensor_path)
    args.output.resolve().parent.mkdir(parents=True, exist_ok=True)
    args.output.resolve().write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"status": report["status"], "environment_seed": args.environment_seed, "repetitions": report["repetitions"], "output": str(args.output.resolve())}, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
