"""Build the frozen T1 tensor from three complete environment-seed batches."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from ranksplit_environment_seed_transfer_contract import (  # noqa: E402
    build_tensor_payload,
    validate_tensor_payload,
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--small", type=Path, required=True)
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--rt1", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    protocol = args.protocol.resolve()
    raw_paths = {
        "octo-small": args.small.resolve(),
        "octo-base": args.base.resolve(),
        "rt-1-x": args.rt1.resolve(),
    }
    payload = build_tensor_payload(protocol_path=protocol, raw_paths=raw_paths)
    validate_tensor_payload(payload, protocol=json.loads(protocol.read_text(encoding="utf-8")), protocol_path=protocol)
    args.output.resolve().parent.mkdir(parents=True, exist_ok=True)
    args.output.resolve().write_text(
        json.dumps(payload, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(json.dumps({"status": payload["status"], "scenarios": payload["scenario_count"], "output": str(args.output.resolve())}, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
