"""Verify the self-contained T1 environment-seed transfer release.

This command is a cold-consumer verifier, not a new evaluator.  It checks the
release manifest, rejects missing or extra payload bytes, loads the frozen
protocol and its source snapshot, validates the three raw acquisitions and the
tensor, then reconstructs the canonical merged report from the twelve frozen
replay shards.  The stored merged report must be byte-content equivalent to
that reconstruction.  A result branch is reported only after integrity and
endpoint checks pass; this command never selects a replacement artifact or
changes a scientific outcome.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path, PurePosixPath
import sys
from typing import Any


sys.dont_write_bytecode = True


MANIFEST_NAME = "MANIFEST.json"
PROTOCOL_RELATIVE = (
    "source/configs/protocols/2026-08-06-ranksplit-environment-seed-transfer.pre-result.json"
)
SCENARIO_MANIFEST_RELATIVE = (
    "source/configs/manifests/2026-07-14-task-profile-follow-up-scenarios.json"
)
EVALUATOR_RELATIVE = "source/scripts/merge-ranksplit-environment-seed-transfer-replays.py"
VERIFIER_RELATIVE = "source/scripts/verify-ranksplit-t1-environment-seed-transfer-release.py"
TENSOR_RELATIVE = "generated/tensor-policy-order-a.json"
SECOND_TENSOR_RELATIVE = "generated/tensor-policy-order-b.json"
MERGED_RELATIVE = "generated/merged-t1-replay.json"
RAW_RELATIVES = {
    "octo-small": "raw/2026-08-06-octo-small-ranksplit-environment-seed-transfer.json",
    "octo-base": "raw/2026-08-06-octo-base-ranksplit-environment-seed-transfer.json",
    "rt-1-x": "raw/2026-08-08-rt-1-x-ranksplit-environment-seed-transfer-repaired.json",
}
SHARD_RELATIVES = tuple(
    f"generated/replay-seed-{seed}.json" for seed in range(100, 112)
)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def safe_relative(value: str) -> PurePosixPath:
    path = PurePosixPath(value)
    require(
        not path.is_absolute() and ".." not in path.parts and bool(path.parts),
        f"unsafe release path: {value!r}",
    )
    return path


def target(root: Path, relative: str) -> Path:
    return root.joinpath(*safe_relative(relative).parts)


def load_manifest(path: Path) -> tuple[dict[str, Any], dict[str, dict[str, Any]]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    require(payload.get("schema_version") == 1, "T1 release manifest schema changed")
    require(
        payload.get("candidate") == "ranksplit-t1-environment-seed-transfer",
        "T1 release candidate identity changed",
    )
    require(
        payload.get("evidence_class") == "environment-seed-tensor-transfer",
        "T1 release evidence class changed",
    )
    require(payload.get("contains_scientific_outcomes") is True, "T1 release outcome flag changed")
    files = payload.get("files")
    require(isinstance(files, list) and files, "T1 release file inventory is missing")

    entries: dict[str, dict[str, Any]] = {}
    for entry in files:
        require(isinstance(entry, dict), "T1 release file entry is not an object")
        relative = entry.get("archive_path")
        require(isinstance(relative, str), "T1 release file path is not a string")
        safe = safe_relative(relative)
        require(safe.as_posix() == relative, f"T1 release path is not canonical POSIX: {relative!r}")
        require(relative != MANIFEST_NAME, "T1 manifest must not list itself")
        require(relative not in entries, f"duplicate T1 release path: {relative}")
        byte_count = entry.get("bytes")
        require(isinstance(byte_count, int) and byte_count >= 0, f"invalid byte count: {relative}")
        expected_hash = entry.get("sha256")
        require(
            isinstance(expected_hash, str)
            and len(expected_hash) == 64
            and expected_hash == expected_hash.lower()
            and all(character in "0123456789abcdef" for character in expected_hash),
            f"invalid SHA-256: {relative}",
        )
        require(isinstance(entry.get("role"), str) and entry["role"], f"missing role: {relative}")
        require(isinstance(entry.get("scientific_input"), bool), f"missing scientific-input flag: {relative}")
        entries[relative] = entry

    source = payload.get("source")
    require(isinstance(source, dict), "T1 release source coordinate is missing")
    for key in (
        "source_revision",
        "t1_protocol_sha256",
        "scenario_manifest_sha256",
        "evaluator_sha256",
        "verifier_sha256",
    ):
        require(isinstance(source.get(key), str) and source[key], f"T1 release source field is missing: {key}")
    interpretation = payload.get("interpretation")
    require(isinstance(interpretation, dict), "T1 release interpretation is missing")
    require(
        interpretation.get("reported_summary") in {"PASS", "PARTIAL", "NEGATIVE", "FAIL-INTEGRITY"},
        "T1 release result branch is not declared",
    )
    require(
        interpretation.get("provenance") == "descriptive-post-outcome-summary",
        "T1 release branch provenance changed",
    )
    require(
        interpretation.get("prose_semantics_frozen_before_outcome") is False,
        "T1 release falsely claims prose branch semantics were pre-frozen",
    )
    return payload, entries


def verify_manifest_files(root: Path, entries: dict[str, dict[str, Any]]) -> dict[str, Any]:
    actual: dict[str, Path] = {}
    for path in root.rglob("*"):
        if path.name == MANIFEST_NAME and path == root / MANIFEST_NAME:
            continue
        if path.is_symlink():
            raise ValueError(f"symlink is not allowed in T1 release: {path.relative_to(root)}")
        if path.is_file():
            relative = path.relative_to(root).as_posix()
            actual[relative] = path

    require(set(actual) == set(entries), "T1 release has missing or extra payload files")
    total_bytes = 0
    for relative, entry in entries.items():
        path = actual[relative]
        observed_bytes = path.stat().st_size
        observed_hash = sha256(path)
        require(observed_bytes == int(entry["bytes"]), f"T1 release byte count drift: {relative}")
        require(observed_hash == str(entry["sha256"]), f"T1 release hash drift: {relative}")
        total_bytes += observed_bytes
    return {"file_count": len(entries), "payload_bytes": total_bytes, "all_member_bytes_exact": True}


def load_source_module(name: str, path: Path) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    require(spec is not None and spec.loader is not None, f"cannot load release source: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def load_release_modules(root: Path) -> tuple[Any, Any]:
    source_scripts = target(root, "source/scripts")
    contract_path = source_scripts / "ranksplit_environment_seed_transfer_contract.py"
    evaluator_path = target(root, EVALUATOR_RELATIVE)
    require(contract_path.is_file(), "T1 release contract source is missing")
    require(evaluator_path.is_file(), "T1 release evaluator source is missing")
    if str(source_scripts) not in sys.path:
        sys.path.insert(0, str(source_scripts))
    contract = load_source_module("ranksplit_environment_seed_transfer_contract", contract_path)
    evaluator = load_source_module("ranksplit_t1_release_merge_evaluator", evaluator_path)
    return contract, evaluator


def close_enough(observed: float, expected: float, label: str) -> None:
    require(
        math.isclose(observed, expected, rel_tol=1e-12, abs_tol=1e-12),
        f"T1 release numerical receipt drift: {label}",
    )


def verify_numerical_receipt(report: dict[str, Any], manifest: dict[str, Any]) -> None:
    summary = manifest["scientific_contract"]["outcome_summary"]
    program_summaries = report["evaluation"]["program_summaries"]
    for role, key in (
        ("ranksplit:lambda-0.50", "ranksplit_primary_aubc"),
        ("matched-eig", "matched_eig_primary_aubc"),
        ("fixed-preference:lambda-0.50", "fixed_preference_precursor_primary_aubc"),
        ("srank-singleton", "srank_singleton_primary_aubc"),
        ("saad-taskwise-d1", "saad_taskwise_d1_primary_aubc"),
    ):
        close_enough(float(program_summaries[role]["primary_aubc"]), float(summary[key]), key)

    comparisons = report["evaluation"]["primary_contrasts"]["comparisons"]
    contrast_receipts = summary["contrasts"]
    role_map = {
        "matched-eig": "vs_matched_eig",
        "fixed-preference:lambda-0.50": "vs_fixed_preference_precursor",
        "srank-singleton": "vs_srank_singleton",
        "saad-taskwise-d1": "vs_saad_taskwise_d1",
    }
    for role, receipt_key in role_map.items():
        observed = comparisons[role]
        expected = contrast_receipts[receipt_key]
        close_enough(float(observed["mean_delta"]), float(expected["delta"]), f"{receipt_key}/delta")
        close_enough(float(observed["ci_low"]), float(expected["interval"][0]), f"{receipt_key}/ci_low")
        close_enough(float(observed["ci_high"]), float(expected["interval"][1]), f"{receipt_key}/ci_high")


def verify_release(root: Path) -> dict[str, Any]:
    root = root.resolve()
    require(root.is_dir(), f"T1 release root is not a directory: {root}")
    manifest_path = root / MANIFEST_NAME
    require(manifest_path.is_file(), "T1 release MANIFEST.json is missing")
    manifest, entries = load_manifest(manifest_path)
    inventory = verify_manifest_files(root, entries)

    protocol_path = target(root, PROTOCOL_RELATIVE)
    scenario_manifest_path = target(root, SCENARIO_MANIFEST_RELATIVE)
    evaluator_path = target(root, EVALUATOR_RELATIVE)
    verifier_path = target(root, VERIFIER_RELATIVE)
    require(sha256(protocol_path) == manifest["source"]["t1_protocol_sha256"], "T1 protocol receipt drift")
    require(
        sha256(scenario_manifest_path) == manifest["source"]["scenario_manifest_sha256"],
        "T1 scenario manifest receipt drift",
    )
    require(sha256(evaluator_path) == manifest["source"]["evaluator_sha256"], "T1 evaluator receipt drift")
    require(sha256(verifier_path) == manifest["source"]["verifier_sha256"], "T1 verifier receipt drift")

    contract, evaluator = load_release_modules(root)
    protocol = contract.load_protocol(protocol_path)
    raw_paths = {role: target(root, relative) for role, relative in RAW_RELATIVES.items()}
    validated_protocol, scenario_manifest, _raw_index = contract.validate_raw_files(protocol_path, raw_paths)
    require(validated_protocol == protocol, "T1 protocol was loaded inconsistently")

    tensor_path = target(root, TENSOR_RELATIVE)
    second_tensor_path = target(root, SECOND_TENSOR_RELATIVE)
    tensor = json.loads(tensor_path.read_text(encoding="utf-8"))
    contract.validate_tensor_payload(tensor, protocol=protocol, protocol_path=protocol_path)
    require(tensor_path.read_bytes() == second_tensor_path.read_bytes(), "T1 tensor validation copies differ")

    shard_paths = [target(root, relative) for relative in SHARD_RELATIVES]
    reconstructed = evaluator.merge_payloads(
        protocol_path=protocol_path,
        tensor_path=tensor_path,
        shard_paths=shard_paths,
        evaluator_path=evaluator_path,
    )
    reconstructed["evaluation"] = evaluator.evaluate(reconstructed, protocol, evaluator_path)
    reconstructed["outcomes_interpreted"] = True
    merged_path = target(root, MERGED_RELATIVE)
    stored = json.loads(merged_path.read_text(encoding="utf-8"))
    require(stored == reconstructed, "canonical merged T1 report is not reproducible from release shards")
    evaluation = stored["evaluation"]
    require(evaluation["status"] == manifest["interpretation"]["reported_summary"], "T1 result branch receipt drift")
    require(evaluation["endpoint_identity"]["passes"] is True, "T1 endpoint identity does not pass")
    require(evaluation["interpretation"]["outcomes_interpreted"] is True, "T1 merged outcome flag changed")
    verify_numerical_receipt(stored, manifest)

    return {
        "status": "pass",
        "candidate": manifest["candidate"],
        "evidence_class": manifest["evidence_class"],
        "source_revision": manifest["source"]["source_revision"],
        "manifest": inventory,
        "scenario_count": len(scenario_manifest["scenarios"]),
        "environment_seeds": list(protocol["environment_seeds"]),
        "tensor_repetitions": int(protocol["replay"]["tensor_repetitions"]),
        "merged_sha256": sha256(merged_path),
        "result_branch": evaluation["status"],
        "endpoint_identity": evaluation["endpoint_identity"],
        "claim_boundary": manifest["interpretation"]["claim_boundary"],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release-root", type=Path, required=True)
    args = parser.parse_args()
    try:
        report = verify_release(args.release_root)
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as error:
        print(json.dumps({"status": "fail", "error": str(error)}, indent=2, sort_keys=True))
        return 1
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
