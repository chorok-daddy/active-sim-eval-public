"""Merge and evaluate the frozen T1 tensor-level replay.

The replay shards are outcome-free by construction.  This entry point is the
first place where efficacy is computed, and it is deliberately source-bound
and fail-closed: the frozen protocol supplies the programs, budgets, metric,
critical value, margins, and result branches.  Inference is over twelve
environment-seed tensor means; the fifty paths inside each tensor are nested
and are never treated as independent tensors.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics
from typing import Any

from ranksplit_environment_seed_transfer_contract import (
    BUDGETS,
    CRITICAL_VALUE,
    ENVIRONMENT_SEEDS,
    FULL_ENDPOINT,
    POLICY_ORDER,
    PRIMARY_BUDGETS,
    PRIMARY_METRIC,
    PROGRAM_ORDER,
    RESULT_BRANCHES,
    SAFEGUARD_METRICS,
    TENSOR_REPETITIONS,
    load_protocol,
    require,
    sha256,
    validate_tensor_payload,
)


ROW_METRICS = (
    "task_weak_order_exact_rate",
    "task_pair_relation_accuracy",
    "task_top_set_jaccard",
    "mean_task_gap_mae",
    "mean_decision_regret",
    "runtime_seconds",
)
IDENTITY_METRICS = ROW_METRICS[:-1]
REPLAY_STATUS = "complete-tensor-replay-no-evaluation"
MERGED_STATUS = "complete-ranksplit-environment-seed-transfer-replay"
BRANCH_SEMANTICS_PROVENANCE = (
    "descriptive-post-result-summary: the protocol froze allowed labels and "
    "numerical gate inputs, but not this prose mapping"
)
BRANCH_SEMANTICS = {
    "PASS": "all four primary comparator intervals clear, safeguards pass, and endpoint identity passes",
    "PARTIAL": "at least one but fewer than all four primary comparator intervals clear, safeguards pass, and endpoint identity passes",
    "NEGATIVE": "integrity passes but no primary comparator interval clears, or a safeguard fails",
    "FAIL-INTEGRITY": "source, coverage, or endpoint integrity fails; no efficacy interpretation",
}


def _finite(value: Any, label: str) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"non-numeric value: {label}") from exc
    require(math.isfinite(number), f"non-finite value: {label}")
    return number


def _expected_programs(protocol: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        {
            "role": str(row["role"]),
            "family": str(row["family"]),
            "preference_lambda": float(row["preference_lambda"]),
        }
        for row in protocol["programs"]
    ]


def _expected_source(
    *, protocol_path: Path, tensor_path: Path, replay_path: Path
) -> dict[str, str]:
    root = replay_path.resolve().parents[1]
    return {
        "protocol_sha256": sha256(protocol_path),
        "tensor_sha256": sha256(tensor_path),
        "replay_sha256": sha256(root / "scripts" / "replay-ranksplit-environment-seed-transfer.py"),
        "allocator_sha256": sha256(root / "scripts" / "ranksplit_established_ranking_allocators.py"),
        "ranksplit_v2_sha256": sha256(root / "scripts" / "ranksplit_v2.py"),
        "metrics_sha256": sha256(root / "scripts" / "ranksplit_ranking_metrics.py"),
    }


def endpoint_identity(rows: dict[str, Any]) -> dict[str, Any]:
    """Check all endpoint identity fields across all programs and repetitions."""

    endpoint = str(FULL_ENDPOINT)
    mismatches: list[dict[str, Any]] = []
    reference = PROGRAM_ORDER[0]
    for role in PROGRAM_ORDER[1:]:
        for repetition, (left, right) in enumerate(
            zip(rows[reference][endpoint], rows[role][endpoint])
        ):
            for metric in IDENTITY_METRICS:
                if left[metric] != right[metric]:
                    mismatches.append(
                        {
                            "role": role,
                            "repetition": repetition,
                            "metric": metric,
                            "reference": left[metric],
                            "observed": right[metric],
                        }
                    )
                    if len(mismatches) >= 10:
                        return {
                            "passes": False,
                            "checked_repetitions": TENSOR_REPETITIONS,
                            "first_mismatches": mismatches,
                        }
    return {
        "passes": not mismatches,
        "checked_repetitions": TENSOR_REPETITIONS,
        "first_mismatches": mismatches,
    }


def _validate_shard(
    shard: dict[str, Any],
    *,
    expected_source: dict[str, str],
    expected_programs: list[dict[str, Any]],
) -> dict[str, Any]:
    require(shard.get("schema_version") == 1, "T1 shard schema changed")
    require(shard.get("status") == REPLAY_STATUS, "T1 shard is not a complete no-evaluation replay")
    require(shard.get("evidence_class") == "environment-seed-tensor-transfer", "T1 shard evidence class changed")
    seed = int(shard.get("environment_seed", -1))
    require(seed in ENVIRONMENT_SEEDS, f"T1 shard seed is outside the freeze: {seed}")
    require(int(shard.get("repetitions", -1)) == TENSOR_REPETITIONS, "T1 shard repetition count changed")
    require(
        list(map(int, shard.get("repetition_indices", ()))) == list(range(TENSOR_REPETITIONS)),
        "T1 shard repetition order or coverage changed",
    )
    require(list(map(int, shard.get("budgets", ()))) == list(BUDGETS), "T1 shard budgets changed")
    require(
        list(map(int, shard.get("primary_budgets", ()))) == list(PRIMARY_BUDGETS),
        "T1 shard primary budgets changed",
    )
    require(list(shard.get("policy_order", ())) == list(POLICY_ORDER), "T1 shard policy order changed")
    require(
        list(shard.get("task_names", ())) == [
            "PutCarrotOnPlateInScene-v1",
            "PutSpoonOnTableClothInScene-v1",
            "StackGreenCubeOnYellowCubeBakedTexInScene-v1",
            "PutEggplantInBasketScene-v1",
        ],
        "T1 shard task order changed",
    )
    require(shard.get("programs") == expected_programs, "T1 shard program order or parameters changed")
    require(shard.get("source") == expected_source, "T1 shard source identity changed")

    rows = shard.get("rows")
    traces = shard.get("action_trace_sha256")
    require(isinstance(rows, dict) and isinstance(traces, dict), "T1 shard rows or traces are missing")
    require(set(rows) == set(PROGRAM_ORDER), "T1 shard row program roles changed")
    require(set(traces) == set(PROGRAM_ORDER), "T1 shard trace program roles changed")
    for role in PROGRAM_ORDER:
        require(set(rows[role]) == {str(budget) for budget in BUDGETS}, f"T1 shard budget rows changed: {role}")
        values_by_budget = rows[role]
        require(len(traces[role]) == TENSOR_REPETITIONS, f"T1 shard trace coverage changed: {role}")
        for trace in traces[role]:
            require(isinstance(trace, str) and len(trace) == 64, f"T1 trace digest malformed: {role}")
            try:
                int(trace, 16)
            except ValueError as exc:
                raise ValueError(f"T1 trace digest is not hexadecimal: {role}") from exc
        for budget in BUDGETS:
            values = values_by_budget[str(budget)]
            require(len(values) == TENSOR_REPETITIONS, f"T1 shard row coverage changed: {role}/{budget}")
            for repetition, row in enumerate(values):
                require(set(row) == set(ROW_METRICS), f"T1 metric schema changed: {role}/{budget}/{repetition}")
                for metric in ROW_METRICS:
                    _finite(row[metric], f"{role}/{budget}/{repetition}/{metric}")

    return {
        "environment_seed": seed,
        "endpoint_identity": endpoint_identity(rows),
    }


def merge_payloads(
    *,
    protocol_path: Path,
    tensor_path: Path,
    shard_paths: list[Path],
    evaluator_path: Path,
) -> dict[str, Any]:
    protocol = load_protocol(protocol_path)
    tensor = json.loads(tensor_path.read_text(encoding="utf-8"))
    validate_tensor_payload(tensor, protocol=protocol, protocol_path=protocol_path)
    require(len(shard_paths) == len(ENVIRONMENT_SEEDS), "T1 requires exactly twelve replay shards")
    require(len({path.name for path in shard_paths}) == len(shard_paths), "duplicate T1 shard path")

    expected_source = _expected_source(
        protocol_path=protocol_path, tensor_path=tensor_path, replay_path=evaluator_path
    )
    expected_programs = _expected_programs(protocol)
    payloads: list[tuple[int, Path, dict[str, Any], dict[str, Any]]] = []
    for path in shard_paths:
        payload = json.loads(path.read_text(encoding="utf-8"))
        receipt = _validate_shard(
            payload, expected_source=expected_source, expected_programs=expected_programs
        )
        payloads.append((receipt["environment_seed"], path, payload, receipt))
    require(
        sorted(seed for seed, _path, _payload, _receipt in payloads) == list(ENVIRONMENT_SEEDS),
        "T1 shard seed coverage is not exactly 100..111",
    )

    payloads.sort(key=lambda item: item[0])
    endpoint_by_seed = {
        str(seed): receipt["endpoint_identity"]
        for seed, _path, _payload, receipt in payloads
    }
    endpoint_passes = all(item["passes"] for item in endpoint_by_seed.values())
    return {
        "schema_version": 1,
        "status": MERGED_STATUS,
        "evidence_class": protocol["evidence_class"],
        "environment_seeds": list(ENVIRONMENT_SEEDS),
        "repetitions": TENSOR_REPETITIONS,
        "tensor_count": len(payloads),
        "total_paths": len(payloads) * TENSOR_REPETITIONS,
        "budgets": list(BUDGETS),
        "primary_budgets": list(PRIMARY_BUDGETS),
        "policy_order": list(POLICY_ORDER),
        "programs": expected_programs,
        "tensor_replays": [
            {
                "environment_seed": seed,
                "rows": payload["rows"],
                "action_trace_sha256": payload["action_trace_sha256"],
            }
            for seed, _path, payload, _receipt in payloads
        ],
        "endpoint_identity": {
            "passes": endpoint_passes,
            "required": True,
            "by_environment_seed": endpoint_by_seed,
        },
        "source": {
            **expected_source,
            "evaluator_sha256": sha256(evaluator_path),
            "shards": {path.name: sha256(path) for _seed, path, _payload, _receipt in payloads},
        },
        "outcomes_interpreted": False,
    }


def interval(values: list[float], critical: float) -> dict[str, float | int]:
    require(len(values) >= 2, "T1 tensor-level interval requires at least two tensors")
    mean = statistics.fmean(values)
    standard_error = statistics.stdev(values) / math.sqrt(len(values))
    half_width = critical * standard_error
    return {
        "n": len(values),
        "mean_delta": mean,
        "standard_error": standard_error,
        "ci_low": mean - half_width,
        "ci_high": mean + half_width,
        "critical_value": critical,
    }


def _tensor_aubc(tensor: dict[str, Any], role: str, metric: str, repetition: int) -> float:
    return statistics.fmean(
        float(tensor["rows"][role][str(budget)][repetition][metric])
        for budget in PRIMARY_BUDGETS
    )


def tensor_level_deltas(
    report: dict[str, Any], candidate: str, comparator: str, metric: str
) -> list[float]:
    deltas = []
    for tensor in report["tensor_replays"]:
        path_deltas = [
            _tensor_aubc(tensor, candidate, metric, repetition)
            - _tensor_aubc(tensor, comparator, metric, repetition)
            for repetition in range(TENSOR_REPETITIONS)
        ]
        deltas.append(statistics.fmean(path_deltas))
    return deltas


def _mean_by_budget(report: dict[str, Any], role: str, metric: str) -> dict[str, float]:
    values: dict[str, float] = {}
    for budget in BUDGETS:
        flattened = [
            float(row[metric])
            for tensor in report["tensor_replays"]
            for row in tensor["rows"][role][str(budget)]
        ]
        values[str(budget)] = statistics.fmean(flattened)
    return values


def _program_summaries(report: dict[str, Any]) -> dict[str, Any]:
    summaries: dict[str, Any] = {}
    for role in PROGRAM_ORDER:
        summaries[role] = {
            PRIMARY_METRIC: _mean_by_budget(report, role, PRIMARY_METRIC),
            "mean_task_gap_mae": _mean_by_budget(report, role, "mean_task_gap_mae"),
            "mean_decision_regret": _mean_by_budget(report, role, "mean_decision_regret"),
            "primary_aubc": statistics.fmean(
                float(row[PRIMARY_METRIC])
                for tensor in report["tensor_replays"]
                for budget in PRIMARY_BUDGETS
                for row in tensor["rows"][role][str(budget)]
            ),
        }
    return summaries


def evaluate(report: dict[str, Any], protocol: dict[str, Any], evaluator_path: Path) -> dict[str, Any]:
    require(report.get("status") == MERGED_STATUS, "T1 merged replay is incomplete")
    require(report.get("environment_seeds") == list(ENVIRONMENT_SEEDS), "T1 merged seed order changed")
    require(int(report.get("tensor_count", -1)) == len(ENVIRONMENT_SEEDS), "T1 tensor count changed")
    require(int(report.get("total_paths", -1)) == len(ENVIRONMENT_SEEDS) * TENSOR_REPETITIONS, "T1 path count changed")
    require(tuple(row["role"] for row in report["programs"]) == PROGRAM_ORDER, "T1 merged program order changed")

    gate = protocol["gate"]
    critical = float(gate["critical_value"])
    candidate = str(gate["primary_program"])
    comparators = [str(role) for role in gate["primary_comparators"]]
    primary = {
        comparator: interval(
            tensor_level_deltas(report, candidate, comparator, PRIMARY_METRIC), critical
        )
        for comparator in comparators
    }
    primary_pass = {comparator: primary[comparator]["ci_low"] > 0.0 for comparator in comparators}

    # The frozen margin contract is EIG-relative, matching the earlier
    # confirmation evaluator.  Ranking-specific programs are the primary
    # comparisons; calibration/decision cost remains a reference safeguard.
    eig = "matched-eig"
    safeguards = {
        metric: interval(
            tensor_level_deltas(report, candidate, eig, metric), critical
        )
        for metric in SAFEGUARD_METRICS
    }
    margins = {metric: float(gate["safeguard_margins"][metric]) for metric in SAFEGUARD_METRICS}
    safeguards_pass = all(
        safeguards[metric]["ci_high"] <= margins[metric] for metric in SAFEGUARD_METRICS
    )
    endpoint = report["endpoint_identity"]
    endpoint_pass = bool(endpoint.get("passes"))

    if not endpoint_pass:
        status = "FAIL-INTEGRITY"
    elif not safeguards_pass:
        status = "NEGATIVE"
    elif all(primary_pass.values()):
        status = "PASS"
    elif any(primary_pass.values()):
        status = "PARTIAL"
    else:
        status = "NEGATIVE"
    require(status in RESULT_BRANCHES, "T1 result branch is outside the freeze")

    return {
        "schema_version": 1,
        "status": status,
        "evidence_class": protocol["evidence_class"],
        "evaluator_sha256": sha256(evaluator_path),
        "branch_semantics": {
            "provenance": BRANCH_SEMANTICS_PROVENANCE,
            "labels": BRANCH_SEMANTICS,
        },
        "primary_contrasts": {
            "candidate": candidate,
            "metric": PRIMARY_METRIC,
            "summary": gate["summary"],
            "inference_unit": "12 tensor-level paired deltas; 50 paths are averaged within each tensor",
            "comparisons": primary,
            "passes": primary_pass,
        },
        "eig_relative_safeguards": {
            "candidate": candidate,
            "comparator": eig,
            "comparisons": safeguards,
            "margins": margins,
            "passes": safeguards_pass,
        },
        "endpoint_identity": endpoint,
        "program_summaries": _program_summaries(report),
        "checks": {
            "source_and_coverage": True,
            "primary_comparator_passes": primary_pass,
            "safeguards_pass": safeguards_pass,
            "endpoint_identity_pass": endpoint_pass,
        },
        "interpretation": {
            "result_branch": status,
            "outcomes_interpreted": True,
            "no_same_block_retuning": True,
            "claim_boundary": protocol["claim_boundary"],
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--tensor", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--shards", type=Path, nargs="+", required=True)
    args = parser.parse_args()

    protocol_path = args.protocol.resolve()
    tensor_path = args.tensor.resolve()
    evaluator_path = Path(__file__).resolve()
    shard_paths = [path.resolve() for path in args.shards]
    report = merge_payloads(
        protocol_path=protocol_path,
        tensor_path=tensor_path,
        shard_paths=shard_paths,
        evaluator_path=evaluator_path,
    )
    protocol = load_protocol(protocol_path)
    report["evaluation"] = evaluate(report, protocol, evaluator_path)
    report["outcomes_interpreted"] = True
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"status": report["evaluation"]["status"], "output": str(output)}, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
