"""Fail-closed source and tensor contract for the T1 transfer study.

T1 reuses the three fixed checkpoints and the official 136-scenario universe,
but changes the finite repetition source to environment seeds 100..111.  This
module validates identity and coverage only; it does not choose a result
branch or interpret any outcome.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
PROTOCOL_PATH = ROOT / "configs" / "protocols" / "2026-08-06-ranksplit-environment-seed-transfer.pre-result.json"
FROZEN_STATUS = "frozen-before-ranksplit-environment-seed-transfer"

ENV_IDS = (
    "PutCarrotOnPlateInScene-v1",
    "PutSpoonOnTableClothInScene-v1",
    "StackGreenCubeOnYellowCubeBakedTexInScene-v1",
    "PutEggplantInBasketScene-v1",
)
ENV_COUNTS = {
    "PutCarrotOnPlateInScene-v1": 24,
    "PutSpoonOnTableClothInScene-v1": 24,
    "StackGreenCubeOnYellowCubeBakedTexInScene-v1": 24,
    "PutEggplantInBasketScene-v1": 64,
}
POLICY_ORDER = ("octo-small", "octo-base", "rt-1-x")
PROGRAM_ORDER = (
    "matched-eig",
    "fixed-preference:lambda-0.50",
    "saad-taskwise-d1",
    "srank-singleton",
    "ranksplit:lambda-0.50",
)
PROGRAM_FAMILIES = {
    "matched-eig": ("matched-eig", 0.0),
    "fixed-preference:lambda-0.50": ("ranksplit", 0.5),
    "saad-taskwise-d1": ("saad-taskwise-d1", 0.0),
    "srank-singleton": ("srank-singleton", 0.0),
    "ranksplit:lambda-0.50": ("clarity-continuation", 0.5),
}
ENVIRONMENT_SEEDS = tuple(range(100, 112))
BUDGETS = (24, 48, 96, 204, 408)
PRIMARY_BUDGETS = (24, 48, 96)
EXPECTED_INITIAL_COUNT = 12
FULL_ENDPOINT = 408
TENSOR_REPETITIONS = 50
TASK_COUNT = len(ENV_IDS)
POLICY_COUNT = len(POLICY_ORDER)
EXPECTED_SCENARIO_COUNT = sum(ENV_COUNTS.values())
EXPECTED_RAW_ROWS = EXPECTED_SCENARIO_COUNT * len(ENVIRONMENT_SEEDS)
EXPECTED_SAAD_UNION_EVENTS = TASK_COUNT * POLICY_COUNT * max(
    ENV_COUNTS.values()
)
EXPECTED_SRANK_TARGETS = (0, 17, 29)
PRIMARY_METRIC = "task_weak_order_exact_rate"
SAFEGUARD_METRICS = ("mean_task_gap_mae", "mean_decision_regret")
RESULT_BRANCHES = ("PASS", "PARTIAL", "NEGATIVE", "FAIL-INTEGRITY")
CRITICAL_VALUE = 1.959963984540054


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def rooted(relative: str) -> Path:
    path = Path(relative)
    require(not path.is_absolute() and ".." not in path.parts, f"unsafe source path: {relative}")
    return ROOT.joinpath(*path.parts)


def load_manifest(path: Path) -> tuple[dict[str, Any], str]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    require(payload.get("schema_version") == 1, "T1 scenario manifest schema changed")
    require(
        payload.get("status") == "frozen-before-follow-up-acquisition",
        "T1 scenario manifest is not frozen before acquisition",
    )
    require(payload.get("environment_seed") == 0, "T1 manifest environment seed changed")
    scenarios = payload.get("scenarios")
    expected = [
        {"env_id": env_id, "episode_id": episode_id}
        for env_id in ENV_IDS
        for episode_id in range(ENV_COUNTS[env_id])
    ]
    require(scenarios == expected, "T1 scenario order or membership changed")
    require(payload.get("scenario_count") == EXPECTED_SCENARIO_COUNT, "T1 scenario count changed")
    require(
        payload.get("tasks") == {env_id: ENV_COUNTS[env_id] for env_id in ENV_IDS},
        "T1 task counts changed",
    )
    require(
        set(payload) == {"schema_version", "purpose", "environment_seed", "tasks", "scenarios", "scenario_count", "status"},
        "T1 manifest contains an outcome-bearing or unrecognized field",
    )
    return payload, sha256(path)


def _validate_source_hashes(protocol: dict[str, Any]) -> None:
    sources = protocol.get("sources")
    require(isinstance(sources, dict) and sources, "T1 source hash map is missing")
    for name, record in sources.items():
        require(isinstance(record, dict), f"T1 source record is not an object: {name}")
        relative = record.get("path")
        expected = record.get("sha256")
        require(isinstance(relative, str) and isinstance(expected, str), f"T1 source record malformed: {name}")
        target = rooted(relative)
        require(target.is_file(), f"T1 source is missing: {name}")
        require(sha256(target) == expected, f"T1 source hash mismatch: {name}")


def load_protocol(path: Path = PROTOCOL_PATH) -> dict[str, Any]:
    protocol = json.loads(path.read_text(encoding="utf-8"))
    require(protocol.get("schema_version") == 1, "T1 protocol schema changed")
    require(protocol.get("status") == FROZEN_STATUS, "T1 protocol is not frozen")
    require(protocol.get("evidence_class") == "environment-seed-tensor-transfer", "T1 evidence class changed")
    manifest_record = protocol.get("scenario_manifest")
    require(isinstance(manifest_record, dict), "T1 scenario manifest record is missing")
    manifest_path = rooted(str(manifest_record.get("path")))
    manifest, observed_manifest_hash = load_manifest(manifest_path)
    require(observed_manifest_hash == manifest_record.get("sha256"), "T1 scenario manifest hash changed")
    require(protocol.get("scenario_count") == EXPECTED_SCENARIO_COUNT, "T1 protocol scenario count changed")
    require(list(map(int, protocol.get("environment_seeds", ()))) == list(ENVIRONMENT_SEEDS), "T1 environment seeds changed")
    require(protocol.get("policies") and tuple(row.get("role") for row in protocol["policies"]) == POLICY_ORDER, "T1 policy order changed")
    expected_policy = {
        "octo-small": ("hf://rail-berkeley/octo-small", 0, "scripts/octo-small-policy-server.py"),
        "octo-base": ("hf://rail-berkeley/octo-base", 0, "scripts/octo-small-policy-server.py"),
        "rt-1-x": ("/home/researcher/checkpoints/rt_1_x_tf_trained_for_002272480_step", None, "scripts/rt1-x-policy-server.py"),
    }
    for row in protocol["policies"]:
        role = str(row["role"])
        checkpoint, policy_seed, server = expected_policy[role]
        require(row.get("checkpoint") == checkpoint, f"T1 checkpoint changed: {role}")
        require(row.get("policy_seed") == policy_seed, f"T1 policy seed changed: {role}")
        require(row.get("server") == server, f"T1 server changed: {role}")

    programs = protocol.get("programs")
    require(isinstance(programs, list) and tuple(row.get("role") for row in programs) == PROGRAM_ORDER, "T1 program order changed")
    for row in programs:
        role = str(row["role"])
        family, lam = PROGRAM_FAMILIES[role]
        require(row.get("family") == family and float(row.get("preference_lambda")) == lam, f"T1 program changed: {role}")

    sampling = protocol.get("sampling_design")
    require(isinstance(sampling, dict), "T1 sampling design is missing")
    require(list(map(int, sampling.get("budgets", ()))) == list(BUDGETS), "T1 budgets changed")
    require(list(map(int, sampling.get("primary_budgets", ()))) == list(PRIMARY_BUDGETS), "T1 primary budgets changed")
    require(int(sampling.get("expected_initial_count", -1)) == EXPECTED_INITIAL_COUNT, "T1 initial census changed")
    require(sampling.get("without_replacement") is True and int(sampling.get("full_endpoint", -1)) == FULL_ENDPOINT, "T1 endpoint sampling changed")
    require(sampling.get("shared_scenario_permutation_scope") == "task-policy-within-tensor", "T1 permutation scope changed")
    scheduler = sampling.get("outer_task_scheduler")
    require(isinstance(scheduler, dict), "T1 scheduler is missing")
    require(scheduler.get("rule") == "minimum acquired task cells", "T1 scheduler changed")
    require(scheduler.get("tie_break") == "stable_seed(master, outer-task-tie, tensor-seed, repetition, global_step, task)", "T1 scheduler tie rule changed")

    replay = protocol.get("replay")
    require(isinstance(replay, dict), "T1 replay design is missing")
    require(int(replay.get("tensor_repetitions", -1)) == TENSOR_REPETITIONS, "T1 tensor repetition count changed")
    require(int(replay.get("simulation_seed", -1)) == 20260806, "T1 simulation seed changed")
    require(replay.get("permutation_rule") == "stable_seed(master, scenario-order, tensor-seed, repetition, task, policy)", "T1 permutation rule changed")

    allocators = protocol.get("allocators")
    require(isinstance(allocators, dict), "T1 allocator design is missing")
    saad = allocators.get("saad_taskwise_d1")
    require(isinstance(saad, dict) and float(saad.get("delta")) == 0.05, "T1 Saad delta changed")
    require(int(saad.get("familywise_union_events", -1)) == EXPECTED_SAAD_UNION_EVENTS, "T1 Saad union bound changed")
    require(saad.get("true_tie_rule") == "remain unresolved; never force strict order", "T1 Saad tie rule changed")
    srank = allocators.get("srank_singleton")
    require(isinstance(srank, dict), "T1 SRank design is missing")
    require(int(srank.get("horizon_per_task", -1)) == 102 and int(srank.get("rounds", -1)) == 2, "T1 SRank horizon changed")
    require(list(map(int, srank.get("round_targets", ()))) == list(EXPECTED_SRANK_TARGETS), "T1 SRank targets changed")
    require(list(map(int, srank.get("singleton_clusters", ()))) == [1, 1, 1], "T1 SRank cluster contract changed")

    gate = protocol.get("gate")
    require(isinstance(gate, dict), "T1 gate is missing")
    require(gate.get("primary_program") == "ranksplit:lambda-0.50", "T1 primary program changed")
    require(tuple(gate.get("primary_comparators", ())) == tuple(PROGRAM_ORDER[:-1]), "T1 primary comparator set changed")
    require(gate.get("primary_metric") == PRIMARY_METRIC, "T1 primary metric changed")
    require(float(gate.get("critical_value")) == CRITICAL_VALUE, "T1 critical value changed")
    require(gate.get("safeguard_margins") == {"mean_task_gap_mae": 0.01, "mean_decision_regret": 0.005}, "T1 safeguards changed")
    require(gate.get("full_endpoint_identity_required") is True, "T1 endpoint gate changed")
    require(tuple(protocol.get("result_branches", ())) == RESULT_BRANCHES, "T1 result branch order changed")
    _validate_source_hashes(protocol)
    return protocol


def expected_scenarios(manifest: dict[str, Any]) -> list[tuple[str, int]]:
    return [(str(row["env_id"]), int(row["episode_id"])) for row in manifest["scenarios"]]


def _expected_policy(protocol: dict[str, Any], role: str) -> dict[str, Any]:
    return next(row for row in protocol["policies"] if row["role"] == role)


def validate_raw_payload(
    payload: dict[str, Any], *, role: str, protocol: dict[str, Any], manifest: dict[str, Any]
) -> dict[tuple[int, str, int], dict[str, Any]]:
    expected = _expected_policy(protocol, role)
    scenarios = expected_scenarios(manifest)
    required_keys = {(seed, env_id, episode_id) for seed in ENVIRONMENT_SEEDS for env_id, episode_id in scenarios}
    require(payload.get("status") == "pass", f"T1 raw output is not complete: {role}")
    require(payload.get("policy_name") == role, f"T1 raw policy identity changed: {role}")
    require(list(map(int, payload.get("environment_seeds", ()))) == list(ENVIRONMENT_SEEDS), f"T1 raw environment seeds changed: {role}")
    require(payload.get("scenario_manifest_sha256") == protocol["scenario_manifest"]["sha256"], f"T1 raw manifest hash changed: {role}")
    require(payload.get("policy_seed") == expected["policy_seed"], f"T1 raw policy seed changed: {role}")
    require(payload.get("checkpoints") == [expected["checkpoint"]], f"T1 raw checkpoint changed: {role}")
    require(int(payload.get("scenario_count", -1)) == EXPECTED_SCENARIO_COUNT, f"T1 raw count changed: {role}/scenario_count")
    for key in ("total_jobs", "completed_jobs", "episodes"):
        require(int(payload.get(key, -1)) == EXPECTED_RAW_ROWS, f"T1 raw count changed: {role}/{key}")
    indexed: dict[tuple[int, str, int], dict[str, Any]] = {}
    for row in payload.get("results", []):
        key = (int(row["seed"]), str(row["env_id"]), int(row["episode_id"]))
        require(key not in indexed and key in required_keys, f"T1 raw duplicate or unexpected row: {role}/{key}")
        require(row.get("checkpoint") == expected["checkpoint"], f"T1 row checkpoint changed: {role}/{key}")
        require(row.get("policy_seed") == expected["policy_seed"], f"T1 row policy seed changed: {role}/{key}")
        require(isinstance(row.get("final_success"), bool), f"T1 row outcome is not Boolean: {role}/{key}")
        indexed[key] = row
    require(set(indexed) == required_keys, f"T1 raw coverage changed: {role}")
    return indexed


def validate_raw_files(protocol_path: Path, raw_paths: dict[str, Path]):
    protocol = load_protocol(protocol_path)
    manifest, _ = load_manifest(rooted(str(protocol["scenario_manifest"]["path"])))
    require(tuple(raw_paths) == POLICY_ORDER, "T1 raw path order changed")
    indexed = {
        role: validate_raw_payload(
            json.loads(path.read_text(encoding="utf-8")),
            role=role,
            protocol=protocol,
            manifest=manifest,
        )
        for role, path in raw_paths.items()
    }
    return protocol, manifest, indexed


def build_tensor_payload(
    *, protocol_path: Path, raw_paths: dict[str, Path]
) -> dict[str, Any]:
    protocol, manifest, indexed = validate_raw_files(protocol_path, raw_paths)
    records = []
    for env_id, episode_id in expected_scenarios(manifest):
        policies: dict[str, Any] = {}
        for role in POLICY_ORDER:
            outcomes = [
                int(bool(indexed[role][(seed, env_id, episode_id)]["final_success"]))
                for seed in ENVIRONMENT_SEEDS
            ]
            policies[role] = {"environment_seed_outcomes": outcomes}
        records.append({"env_id": env_id, "episode_id": episode_id, "policies": policies})
    return {
        "schema_version": 1,
        "analysis_type": "ranksplit environment-seed transfer tensor",
        "evaluation_scope": "fixed-checkpoint environment-seed tensor transfer",
        "source_sha256": {
            "frozen_protocol": sha256(protocol_path),
            "scenario_manifest": protocol["scenario_manifest"]["sha256"],
            **{role: sha256(path) for role, path in raw_paths.items()},
        },
        "environment_seeds": list(ENVIRONMENT_SEEDS),
        "scenario_count": EXPECTED_SCENARIO_COUNT,
        "policy_order": list(POLICY_ORDER),
        "scenario_records": records,
        "status": "pass",
    }


def validate_tensor_payload(payload: dict[str, Any], *, protocol: dict[str, Any], protocol_path: Path) -> None:
    require(payload.get("status") == "pass", "T1 tensor is not complete")
    require(payload.get("environment_seeds") == list(ENVIRONMENT_SEEDS), "T1 tensor seed order changed")
    require(payload.get("scenario_count") == EXPECTED_SCENARIO_COUNT, "T1 tensor scenario count changed")
    require(tuple(payload.get("policy_order", ())) == POLICY_ORDER, "T1 tensor policy order changed")
    source = payload.get("source_sha256")
    require(isinstance(source, dict), "T1 tensor source hashes are missing")
    require(source.get("frozen_protocol") == sha256(protocol_path), "T1 tensor protocol hash changed")
    require(source.get("scenario_manifest") == protocol["scenario_manifest"]["sha256"], "T1 tensor manifest hash changed")
    for role in POLICY_ORDER:
        value = source.get(role)
        require(isinstance(value, str) and len(value) == 64, f"T1 tensor raw hash is missing: {role}")
    records = payload.get("scenario_records")
    require(isinstance(records, list) and len(records) == EXPECTED_SCENARIO_COUNT, "T1 tensor records changed")
    expected = {(env_id, episode_id) for env_id, episode_id in expected_scenarios(load_manifest(rooted(str(protocol["scenario_manifest"]["path"])))[0])}
    seen = set()
    for record in records:
        key = (str(record.get("env_id")), int(record.get("episode_id", -1)))
        require(key in expected and key not in seen, f"T1 tensor duplicate or unexpected scenario: {key}")
        seen.add(key)
        policies = record.get("policies")
        require(isinstance(policies, dict) and tuple(policies) == POLICY_ORDER, f"T1 tensor policy schema changed: {key}")
        for role in POLICY_ORDER:
            values = policies[role].get("environment_seed_outcomes")
            require(isinstance(values, list) and len(values) == len(ENVIRONMENT_SEEDS), f"T1 tensor seed coverage changed: {key}/{role}")
            require(all(value in (0, 1) for value in values), f"T1 tensor outcome is not binary: {key}/{role}")
    require(seen == expected, "T1 tensor scenario coverage changed")


__all__ = [
    "BUDGETS",
    "CRITICAL_VALUE",
    "ENVIRONMENT_SEEDS",
    "ENV_IDS",
    "EXPECTED_INITIAL_COUNT",
    "EXPECTED_RAW_ROWS",
    "EXPECTED_SCENARIO_COUNT",
    "EXPECTED_SRANK_TARGETS",
    "FROZEN_STATUS",
    "FULL_ENDPOINT",
    "POLICY_ORDER",
    "PRIMARY_BUDGETS",
    "PRIMARY_METRIC",
    "PROGRAM_ORDER",
    "RESULT_BRANCHES",
    "SAFEGUARD_METRICS",
    "TENSOR_REPETITIONS",
    "build_tensor_payload",
    "expected_scenarios",
    "load_manifest",
    "load_protocol",
    "require",
    "rooted",
    "sha256",
    "validate_raw_files",
    "validate_raw_payload",
    "validate_tensor_payload",
]
