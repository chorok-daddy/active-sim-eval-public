# ActiveSimEval T1 environment-seed transfer result

Status: **PARTIAL** under the frozen 2026-08-06 T1 protocol.  This is a valid
prospective result, not an integrity failure.  The protocol froze the allowed
branch labels and numerical gate inputs, but did not freeze a prose meaning for
`PARTIAL`; here it is a transparent post-outcome summary of the published
intervals.  The label was assigned only after all three policy batches, both
canonical tensors, and all twelve 50-repetition replay shards were complete.

## Decision

Across twelve independently acquired environment-seed tensors of the fixed
Octo-small, Octo-base, and RT-1-X checkpoints, final RankSplit at
`lambda=0.50` improved task weak-order recovery over matched EIG, the
fixed-preference `.50` precursor, and singleton SRank.  It did not improve
over the task-wise `d=1` Saad adaptation.  The predeclared EIG-relative
calibration and decision-regret safeguards passed, as did full endpoint
identity.

The T1 result therefore supports transfer against three declared references,
but does not support a claim that RankSplit is superior to all ranking-specific
allocators.  The Saad result is retained as counterevidence; no seed, policy,
comparator, metric, budget, or gate was removed or retuned.

| Program | B24 | B48 | B96 | B204 | B408 | Primary AUBC |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| matched EIG | 0.305833 | 0.402917 | 0.584583 | 0.759167 | 1.000000 | 0.431111 |
| fixed-preference `.50` | 0.305833 | 0.416250 | 0.560417 | 0.785417 | 1.000000 | 0.427500 |
| Saad task-wise `d=1` | 0.396667 | 0.573750 | 0.771667 | 0.813750 | 1.000000 | 0.580694 |
| SRank singleton | 0.305833 | 0.402917 | 0.551667 | 0.749583 | 1.000000 | 0.420139 |
| RankSplit `.50` | 0.305833 | 0.447500 | 0.619583 | 0.817500 | 1.000000 | 0.457639 |

Primary inference uses `n=12` tensor-level paired deltas.  The 50 paths
nested within each tensor were averaged before forming the interval.

The descriptive branch summary is: `PASS` means all four primary intervals
clear with safeguards and endpoint identity passing; `PARTIAL` means some but
not all primary intervals clear with safeguards and endpoint identity passing;
`NEGATIVE` means no primary interval clears or a safeguard fails; and
`FAIL-INTEGRITY` means source, coverage, or endpoint integrity fails.  These
words document the evaluator's transparent result summary; they are not
presented as outcome-blind prose semantics frozen in the protocol.

| RankSplit minus | Mean delta | SE | Paired 95% normal interval (lower endpoint is directional) | Gate |
| --- | ---: | ---: | ---: | --- |
| matched EIG | +0.0265278 | 0.0020460 | [+0.0225178, +0.0305378] | PASS |
| fixed-preference `.50` | +0.0301389 | 0.0016343 | [+0.0269358, +0.0333420] | PASS |
| Saad task-wise `d=1` | -0.1230556 | 0.0042484 | [-0.1313822, -0.1147289] | FAIL |
| SRank singleton | +0.0375000 | 0.0021468 | [+0.0332924, +0.0417076] | PASS |

## Safeguards and integrity

Safeguards are RankSplit minus matched EIG, following the frozen contract.

| Safeguard | Mean delta | 95% interval | Upper margin | Gate |
| --- | ---: | ---: | ---: | --- |
| Mean task-gap MAE | +0.0025900 | [+0.0017426, +0.0034374] | +0.010 | PASS |
| Mean decision regret | -0.0003746 | [-0.0005756, -0.0001736] | +0.005 | PASS |

Full endpoint identity passed for all 12 tensors and 50 repetitions, with no
reported mismatches.  Raw coverage was `4896/4896`; replay coverage was
`12/12` shards and `600` nested paths.

The first persisted tensor was rejected before replay because sorted JSON keys
reversed the frozen policy order.  The tensor builder was repaired without
changing the scientific design, and the repaired tensor was rebuilt and
validated before replay.  The invalid RT-1-X envelope remains preserved.  No
efficacy output was inspected before the repaired replay was complete.

## Claim boundary

The appropriate reader-facing statement is:

> On the frozen 136-scenario benchmark and twelve environment-seed tensors of
> the three fixed policy checkpoints, final RankSplit improved early task-local
> ranking recovery over matched EIG, the fixed-preference precursor, and
> singleton SRank while staying within the declared EIG-relative safeguards;
> the task-wise Saad adaptation was stronger on this transfer panel.

This is a prospective transfer result, not a universal SOTA claim.  It does
not establish superiority over every ranking method, new policies, new tasks,
new embodiments, real-robot performance, or population generalization.  The
earlier disjoint-block comparator result remains a separate benchmark result;
T1 neither rewrites it nor pools its inference with T1.

## Artifact identity

Windows source-local root:
`source-local`

| Item | SHA-256 |
| --- | --- |
| protocol | `1e6e73d62d30e254d0807f54cb32e0a13698ba172f0566ad8e8ae5b03155bf11` |
| repaired tensor | `1d4290131fc19c7dac32ae0e60855897f45eb29c9fe11064765f5039cfa369d4` |
| merged T1 replay (canonical, provenance-annotated) | `57ce24251793af1cc404672f4131240c725d28cab5460bab90a0d07029a594b9` |
| merge/evaluator source | `f3afb313a26daff759a6c0aefba478de493d55e9f39a2e904e96a8e6e9800443` |
| pre-provenance merged replay (verification copy) | `75b3e90af01beebdf965dfb3e44b51fad47cf5ce0e57f6033bc7d8c2c1320f94` |

The pre-provenance evaluator was generated twice from the same twelve shards;
those two outputs were byte-identical.  A later provenance-only evaluator
revision added the explicit note that `PARTIAL` is a descriptive post-outcome
summary rather than a protocol-frozen prose branch meaning; it preserved every
reported interval and produced the canonical hash above.  Every shard links
the frozen protocol, tensor, replay, allocator, RankSplit, and metrics source
hashes.
